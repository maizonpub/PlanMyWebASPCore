// JavaScript Document
(function( $ ) { 
	"use strict";
    // Add Color Picker to all inputs that have 'color-field' class
    $(function() {
        $('.color-class').wpColorPicker();
    });
})( jQuery );