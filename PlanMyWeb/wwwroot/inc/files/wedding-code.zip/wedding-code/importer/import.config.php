<?php 
$main_over_menus = array(
                  "primary_menu" => "primary",
				  "topbar" => "topbar",
                  );
$homepage_default="Home";
$homepost_default="Blog";
?>